void main() {
    print(5);
    return;
}